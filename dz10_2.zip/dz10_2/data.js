const dataJson = `[

  { 
    "name" : "retriever-golden",
    "img_url": "https://images.dog.ceo/breeds/retriever-golden/n02099601_2359.jpg",
    "desc": "Очень красивая собака"
  },
  {
    "name" : "shihtzu",
    "img_url": "https://images.dog.ceo/breeds/shihtzu/n02086240_8825.jpg",
    "desc": "Невероятно ласковая собака"
  },
  {
    "name" : "rottweiler",
    "img_url": "https://images.dog.ceo/breeds/rottweiler/n02106550_11762.jpg",
    "desc": "Кусачая собака"
  },
  {
    "name" : "i don know",
    "img_url": "https://images.dog.ceo/breeds/springer-english/n02102040_6552.jpg",
    "desc": "Песель что надо"
  },
  {
    "name" : "i don know",
    "img_url": "https://images.dog.ceo/breeds/beagle/n02088364_9650.jpg",
    "desc": "Песель водила"
  },
  {
    "name" : "i don know",
    "img_url": "https://images.dog.ceo/breeds/ovcharka-caucasian/IMG_20190601_185700.jpg",
    "desc": "Собакен обалдакен"
  } 
]`