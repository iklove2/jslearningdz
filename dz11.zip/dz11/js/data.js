const dataJson = `[
  { 
    "img" : "img/product1.jpg",
    "title" : "ellery x m'o capsule",
    "text" : "Known for her sculptural takes on traditional tailoring, Australian arbiter of cool Kym Ellery teams up with Moda Operandi.",
    "price" : 52
  },
  { 
    "img" : "img/product2.png",
    "title" : "ellery x m'o capsule",
    "text" : "Known for her sculptural takes on traditional tailoring, Australian arbiter of cool Kym Ellery teams up with Moda Operandi.",
    "price" : 61
  },
  { 
    "img" : "img/product3.png",
    "title" : "ellery x m'o capsule",
    "text" : "Known for her sculptural takes on traditional tailoring, Australian arbiter of cool Kym Ellery teams up with Moda Operandi.",
    "price" : 34
  },
  { 
    "img" : "img/product4.png",
    "title" : "ellery x m'o capsule",
    "text" : "Known for her sculptural takes on traditional tailoring, Australian arbiter of cool Kym Ellery teams up with Moda Operandi.",
    "price" : 83
  },
  { 
    "img" : "img/product5.png",
    "title" : "ellery x m'o capsule",
    "text" : "Known for her sculptural takes on traditional tailoring, Australian arbiter of cool Kym Ellery teams up with Moda Operandi.",
    "price" : 96
  },
  { 
    "img" : "img/product6.png",
    "title" : "ellery x m'o capsule",
    "text" : "Known for her sculptural takes on traditional tailoring, Australian arbiter of cool Kym Ellery teams up with Moda Operandi.",
    "price" : 25
  }
]`